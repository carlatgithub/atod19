package generic.util.interaction;

public interface AsyncInteractionCallBack {

}
