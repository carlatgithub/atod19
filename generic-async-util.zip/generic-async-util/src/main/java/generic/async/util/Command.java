package generic.async.util;

public interface Command {
	
	public void execute();

}
