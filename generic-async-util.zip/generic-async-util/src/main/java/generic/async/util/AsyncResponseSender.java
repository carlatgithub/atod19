package generic.async.util;

public interface AsyncResponseSender {
	
	public void sendResponseWithAsyncContext(Object responseObj,AsyncContext asynContext);

}
